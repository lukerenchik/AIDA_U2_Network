# __init__.py
from AIDA_Network.segmenter import U2NetSegmenter
from AIDA_Network.ai_detector import AIDetector   

__all__ = ["U2NetSegmenter", "AIDetector"]